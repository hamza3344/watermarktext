﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace watermark
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Image bitmap = Bitmap.FromFile("image.png");
            Graphics g=Graphics.FromImage(bitmap);
            Color stringcolor=Color.FromArgb(90,0,0,0);//first one is for opacity from 0 to 255 and other three is r g b value of color
            string text = "My watermark";
            g.TranslateTransform(100,50);//first value is for x amd other one is y
            g.RotateTransform(30);
            g.DrawString(text, new Font("Arail", 60, FontStyle.Regular), new SolidBrush(stringcolor), new Point(0, 0));
            bitmap.Save("watermarkimage.png");
            pictureBox1.Image=new Bitmap("watermarkimage.png");
        }
    }
}
